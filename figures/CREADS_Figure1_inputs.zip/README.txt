CREADS Figure 1 inputs

Open figures/CREADS_Figure1.ipynb and upload this ZIP.
The archive contains processed regional tables, a Natural Earth basemap,
a reference image and the figure script. GADM boundaries are downloaded
from the official provider during execution and are not redistributed here.
See docs/data_sources.md for data sources and terms.
